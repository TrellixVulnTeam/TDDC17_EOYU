import lab1

lab1.run()
